let massive = [];
for (var i = 0; i < 10; i++) {massive.push(Math.round(Math.random() * 100));}
for (var i = 0; i < massive.length; i++) {console.log(massive[i]);}
